# YGGDRASIL v2.7 — Studio intro + Duel OST

Esta atualização preserva os arquivos de jogo recebidos da base de desenvolvimento v2.6, incluindo o jogo cooperativo, arena X1, Kali, Eve Lore e Xans, e modifica somente a entrada e a trilha do duelo.

## Introdução

A tela inicial mostra por cerca de 5 segundos a arte de lua enviada pelo criador, runas, `YGGDRASIL` e o crédito **A GAME BY DAVIS**. Há botão **PULAR INTRO** e acessibilidade de movimento reduzido. Nenhum outro título, arte de personagem ou regra de combate foi substituído.

Arquivo original da arte: `public/assets/intro/moon_logo.jpg`.

## OST exclusiva do X1

`public/assets/audio/duel_theme.mp3` é uma transcodificação para MP3 da faixa enviada pelo usuário, **Dark RPG Battle – 8-Bit Gothic Combat Theme**. Em `duel.html`, a música é tocada somente na arena X1 após o início da luta; pausa ao terminar, sair da sala, reiniciar ou fechar a página. Loop e volume inicial 26% para não ficar alta. Há botão **ATIVAR OST DO X1** e controle de volume; isso é necessário porque celulares podem bloquear áudio sem interação do usuário. A música não é reproduzida nas ondas cooperativas ou na seleção de cartas.

## Publicação Cloudflare via Codespaces

Na raiz do projeto:

```bash
npm install
npx wrangler deploy
```

Se enviar este ZIP para a raiz do repositório, extraia-o antes de publicar:

```bash
git pull && unzip -o Yggdrasil_Cloudflare_Intro_Duelo_v27.zip -d . && npm install && npx wrangler deploy
```

Atenção: o projeto usa `Cloudflare Workers + Durable Objects` para as salas. Atualize o navegador em todos os dispositivos depois do deploy.

## Verificação

- Verificação de sintaxe de `public/game.js`, `public/duel.js` e `src/worker.mjs` realizada.
- A trilha convertida e os arquivos de logo foram conferidos no pacote.
- O teste visual automatizado em navegador foi impedido por bloqueio de acesso local neste ambiente. A integração online ainda precisa ser testada com dois jogadores e um espectador em Cloudflare.
