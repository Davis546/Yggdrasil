# Yggdrasil v1.9 — Rede fluida + Cross rework (Cloudflare)

Conserva o conteúdo e os gráficos da **v1.8**: Loid, Kris, Cross (Q teleport, E nove ossos, Gaster Blaster), cartas, poderes, Samurai, Reuni, Tsukuomi, Pecado e mapas japoneses.

## Correção de lag para convidados

- Corrige a causa da **movimentação travada**: a reconciliação antiga puxava o personagem para trás contra o comando do jogador a cada quadro, ao usar snapshots atrasados. Agora a predição local só é corrigida fortemente quando há divergência significativa.
- **Canal rápido de movimento**: ~20 pacotes/s pequenos (posições e direções), separado do **estado de combate** (~8 pacotes/s), mantendo o anfitrião como autoridade da simulação.
- Evita filas de estado antigas quando o WebSocket está sobrecarregado, dá prioridade aos comandos e intercala posições dos outros jogadores.
- O medidor exibe FPS, ping, jitter e pacotes recebidos por segundo.

## Modo Desempenho (opcional)

Configurações → Renderização → **Modo Desempenho**: resolução de canvas em ~68% da escala normal, menos partículas e renderização de efeitos menos onerosa. **Não altera os arquivos originais dos sprites ou do mapa**. As opções Automática, Leve e Alta nitidez permanecem.

## Instalação Cloudflare

Envie os arquivos extraídos do ZIP para a raiz do repositório. No GitHub Codespaces:
```bash
npm install && npx wrangler deploy
```
Se o ZIP foi enviado à raiz como arquivo (não extraído):
```bash
git pull && unzip -o Yggdrasil_Cloudflare_Online_Fluido_v19.zip -d . && npm install && npx wrangler deploy
```

## Limitações / teste

Esta é uma otimização importante do movimento de convidado e do custo de rede. **Não é uma garantia de ausência de lag**, especialmente sob latência real alta ou perda de pacotes. Teste duas janelas no mesmo PC e depois três pessoas em celulares diferentes. Compare FPS e ping de anfitrião e convidados; se os dois valores estão altos, o gargalo é duplo (GPU e rede). O servidor permanece host-autoritativo; uma arquitetura com simulação no servidor seria o próximo passo para independência do anfitrião.
