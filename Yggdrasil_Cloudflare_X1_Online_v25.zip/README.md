# YGGDRASIL v2.5 — Duelo X1 online + espectadores

Baseada na v2.4. **Cooperativo de até 3 jogadores preservado**. Foi acrescentado um modo PvP X1 independente, acessível na tela inicial por `⚔ X1 ONLINE · LUTAR OU ASSISTIR` ou diretamente em `/duel.html`.

## Duelo

- Uma sala por código de 6 caracteres; **2 vagas para lutadores** e até 10 espectadores (12 conexões por sala).
- O anfitrião inicia a sala como lutador; quem entra pode escolher lutar ou **assistir**, inclusive no meio do duelo. O espectador não interfere no combate.
- Cada lutador escolhe Loid, Kris ou Xans (não repetidos) e seleciona **3 cartas dentre 6 sorteadas**, individualmente e antes da luta. As cartas são geradas e validadas no servidor. Cartas de eliminação instantânea foram excluídas do PvP por equilíbrio.
- Cada lutador inicia com **11.200 HP**, o valor base do Pecado na dificuldade Normal. Cartas de vida podem elevar esse valor.
- Arena japonesa usando os **mesmos sprites e mapa** que o modo cooperativo. Q, E, R, dash e ataque básicos em duelo com ajustes para PvP.
- O servidor Cloudflare Durable Object mantém a sala; o **anfitrião simula a luta**, incluindo golpes, vida e resultados, e envia o estado compartilhado a convidados e espectadores ~20 vezes/s. Portanto, o anfitrião deve permanecer com o jogo aberto.
- Controles PC: WASD, mouse ou J, Espaço, Q/E/R. Celular: joystick + ataque automático + Q/E/R + dash. O supremo de Kris mantém as quatro opções (Fight, Defesa, Itens, Piedade).
- Depois da luta o anfitrião pode reiniciar o duelo **na mesma sala**, com uma nova rodada de cartas aleatórias.

## Publicar no Cloudflare

1. Faça upload do ZIP para a raiz do repositório GitHub **ou** extraia o ZIP para a raiz do projeto Codespaces.
2. Na raiz do projeto, execute:

```bash
npm install
npx wrangler deploy
```

Se enviou o ZIP completo ao GitHub sem extrair, no Codespaces:

```bash
git pull && unzip -o Yggdrasil_Cloudflare_X1_v25.zip -d . && npm install && npx wrangler deploy
```

O comando `wrangler deploy` atualiza o **mesmo Worker**, sem criar outro projeto, se o nome no `wrangler.jsonc` for preservado.

### Testes recomendados

1. Abra o link `.workers.dev` em duas abas diferentes (ou dois dispositivos). Na primeira, **Criar Sala X1**. Na segunda, **Entrar para lutar** com o código.
2. Cada pessoa escolhe personagem distinto e 3 cartas; o anfitrião inicia.
3. Abra uma terceira aba, **Assistir como espectador**, usando o mesmo código. Confira se o HP dos dois jogadores coincide em todas as telas.
4. Teste ataque, dash, Q, E, R, vitória e revanche mantendo o mesmo código.

**Nota:** O modo PvP é protótipo para testes. O modo cooperativo não foi reescrito. O PvP ainda depende do anfitrião (host-authoritative); para torneios competitivos e antitrapaça, será necessário simular a batalha diretamente no servidor. Se o anfitrião fechar a aba, a sala será encerrada.
