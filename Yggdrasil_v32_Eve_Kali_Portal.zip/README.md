# YGGDRASIL v3.2 — Eve Lorey, Kali e paridade visual entre modos

Base: v3.1, mantendo Loid, Kris e Xans e suas habilidades originais.

## Correções
- Eve Lorey: reconstruídas as animações laterais. A direção esquerda usa perfil espelhado, a direita usa o perfil íntegro, sem quadros cortados.
- Kali: retirada a franja branca somente dos limites transparentes; mantém roupas e brilho do espelho.
- Seleção: retratos estáticos exclusivos `eve_portrait_v32.webp` e `kali_portrait_v32.webp` no cooperativo e X1. Não usar a spritesheet no menu.
- Portal do Eve Lorey: portal pixel art visível na origem e destino no X1 e agora também na campanha/cooperativo; efeitos não alteram dano nem recargas.
- X1: Q do Eve com explosão do Vazio, E com runas de tempo, R com eclipse escuro, Kali com espelhos e ilusões móveis.
- Botões Q/E/R: símbolos ✦/✧/✶ com letra pequena; barras de HP compactas no X1.
- Versão: menus e scripts atualizados para v3.2 (cache bust `v=32`).

## Importante sobre paridade
Os modos continuam com arquivos de combate distintos, mas foram alinhados nos efeitos e nas habilidades existentes; números de dano/vida do X1 são balanceados para o duelo. Não foi efetuada uma migração completa para motor único.

## Publicar
Envie ZIP à raiz do repositório. No Codespaces:

```bash
git pull && unzip -o Yggdrasil_Cloudflare_Eve_Kali_Fix_v32.zip -d . && npm install && npx wrangler deploy
```

Atualize as páginas em todos os navegadores. Cloudflare Workers precisa estar conectado à conta e com Durable Object habilitado.
