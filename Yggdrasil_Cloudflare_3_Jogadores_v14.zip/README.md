# Yggdrasil Online — Cloudflare Workers (teste)

Versão adaptada do projeto Yggdrasil 3 jogadores para Cloudflare Workers + Durable Objects.
O jogo fica em `public/`, e o servidor de salas em `src/worker.mjs`.

## Publicar com GitHub Codespaces

1. No GitHub, abra seu repositório em **Code > Codespaces > Create codespace on main**.
2. Envie os arquivos deste pacote para a raiz do repositório, mantendo as pastas `src/` e `public/`.
3. Abra o terminal do Codespaces em **Terminal > New Terminal**.
4. Execute:
   ```bash
   npm install
   npx wrangler login
   npx wrangler deploy
   ```
5. Abra o link `https://...workers.dev` gerado. O endereço `/health` deve responder com `{"ok":true,...}`.
6. No jogo, escolha **Online Cooperativo** e compartilhe o código de sala com até dois amigos.

**Não use o `server.js` antigo** neste deploy. Cloudflare executa `src/worker.mjs` via `wrangler.jsonc`.

## Limites deste protótipo

- O navegador do anfitrião calcula o combate; o Cloudflare encaminha comandos e atualizações aos outros jogadores.
- Se o anfitrião fechar a aba, a sala acaba.
- Salas temporárias para até três jogadores, sem salvamento e sem reconexão.
- Ainda precisa de teste real com três dispositivos pela internet.
- Cloudflare pode impor cotas de uso, conforme o plano.
