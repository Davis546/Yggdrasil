# YGGDRASIL v2.1 — Coop: fantasmas, aggro e feedback

Base: v2.0. Preserva os gráficos, o rework do Cross, as cartas, os chefes, o modo desempenho e a arquitetura multiplayer Cloudflare.

## Correções
- Números de dano são agregados **por inimigo**, mantidos perto da criatura e limitados em quantidade para não lotar o centro da tela.
- Monstros, projéteis e ataques de boss passam a ignorar jogadores com vida zero; o aggro escolhe o aliado vivo mais próximo, incluindo quando o anfitrião está caído.
- Corrigido caso em que a morte de um convidado fazia o jogo declarar fim da partida mesmo com o anfitrião vivo. O fim só acontece quando todos estão mortos.
- Personagens caídos viram espíritos translúcidos que continuam andando e explorando, sem atacar, sofrer dano, coletar vida ou atrair monstros. O aviso de morte vira uma pequena faixa que não cobre a tela.
- Na próxima onda, os personagens caídos revivem com 50% da vida e 2 s de proteção. A vitória contra chefes mantém a cura total do grupo.
- Interpolação dos inimigos para convidados ajustada para o intervalo real dos pacotes, diminuindo pequenas pausas visuais entre estados.
- Colisões entre inimigos rejeitam separações grandes antes de calcular distância.

## Deploy
Extraia este ZIP na raiz do GitHub Codespaces e execute `npm install && npx wrangler deploy`.
Caso envie o ZIP inteiro ao repositório: `git pull && unzip -o Yggdrasil_Cloudflare_Fantasmas_Coop_v21.zip -d . && npm install && npx wrangler deploy`.
Todos os clientes devem recarregar a página para receber `game.js?v=21`.

## Teste sugerido
Com 2 ou 3 jogadores, faça um convidado morrer. Confira que ele anda transparente, o anfitrião ainda joga e os Onis passam a atacar só quem está vivo. Após a onda, o caído deve voltar com metade da vida. Depois verifique os números de dano sobre cada inimigo.

**Atenção:** testes locais de lógica não são equivalentes a teste real entre 3 conexões Cloudflare; validar após deploy.
