// V6.2.2 — server-authoritative PvP adapter for the real Journey combat engine.
import {createJourneyRuntime622} from '../public/journey-runtime622.mjs';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y),round=(v,n=2)=>Number.isFinite(v)?+v.toFixed(n):0;
export const DUEL_HEROES622=['loid','kris','cross','eve','kali','mollitiam','moretti','l0id','josue','mimic','abloy'];
export function createDuel(fighters){
 const units=fighters.map((x,i)=>({...x,team:i%2,x:i%2?805:643,y:fighters.length===4?(i<2?505:580):545,aim:i%2?Math.PI:0,face:i%2?'left':'right',inputSeq:0,botWait:0,botHold:0}));
 const teams=[0,1].map(t=>({units:units.filter(x=>x.team===t),runtime:createJourneyRuntime622()}));for(const t of teams)t.runtime.init(t.units);
 let clock=0,starting=3,remaining=180,lastAt=performance.now(),seq=0,finished=false,winner=null,winnerTeam=null;
 const living=t=>teams[t].units.filter(x=>x.actor.hp>0);
 function proxy(u){const p=u.actor;const x={id:u.id,type:'duelFighter',pvpFighter:true,radius:10,receive:amount=>teams[u.team].runtime.receive(u,amount)};
 for(const k of ['x','y','hp','maxHp','speed','hurt','slow','stunTime','corruptTime','timeSlow','burnTime','burnTick'])Object.defineProperty(x,k,{enumerable:true,get:()=>p[k]??0,set:v=>{if(Number.isFinite(v))p[k]=v;}});return x;}
 const proxies=units.map(u=>({u,p:proxy(u)}));
 const targets=t=>proxies.filter(x=>x.u.team!==t&&x.u.actor.hp>0).map(x=>x.p);
 function refresh(t){teams[t].runtime.refreshTargets(targets(t));}
 function act(u,name,variant,aim){if(starting>0||finished||u.actor.hp<=0)return false;const p=u.actor;if(Number.isFinite(aim)){p.aim=aim;p.input.aim=aim;}refresh(u.team);return teams[u.team].runtime.press(u,name,variant);}
 function bot(u,dt){const p=u.actor;if(p.hp<=0)return;u.botWait-=dt;if(u.botWait>0)return;u.botWait=.14+Math.random()*.07;const other=living(1-u.team).sort((x,y)=>dist(x.actor,p)-dist(y.actor,p))[0];if(!other)return;const e=other.actor,dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy)||1,aim=Math.atan2(dy,dx),r=p.reach||40,ranged=['kali','abloy'].includes(p.type),ideal=ranged?r*.64:r*.75,forward=d>ideal+8?1:d<ideal-12&&ranged?-.6:0,side=Math.sin(clock*1.7+u.team)>0?.22:-.22;
 p.input={x:clamp(dx/d*forward-dy/d*side,-1,1),y:clamp(dy/d*forward+dx/d*side,-1,1),aim,attack:d<r+14};p.inputAt=performance.now();p.aim=aim;
 if(p.secondaryCharging&&p.secondaryCharge>=1.25){act(u,'eUp','',aim);return;}
 if(p.type==='mimic'&&clock>5){act(u,'mimic','kris',aim);return;}
 if(p.ultimateCharge>=100){act(u,'r',p.hp<p.maxHp*.4?'piedade':'fight',aim);return;}
 const injured=living(u.team).some(x=>x.actor.hp<x.actor.maxHp*.78);
 if(p.skillCd<=0&&(d<Math.max(r+35,160)||['moretti','kali'].includes(p.type)&&injured)){act(u,'q','',aim);return;}
 if(p.secondaryCd<=0&&!p.secondaryCharging&&(d<Math.max(r+40,185)||injured)){act(u,'eDown','',aim);return;}
 if(p.dashCd<=0&&d>r+100){act(u,'dash','',aim);}
 }
 function step(dt){clock+=dt;if(starting>0){starting=Math.max(0,starting-dt);return;}remaining=Math.max(0,remaining-dt);
 for(const u of units){const p=u.actor;if(!u.bot&&performance.now()-p.inputAt>350)p.input={...p.input,x:0,y:0,attack:false};if(u.bot)bot(u,dt);p.pvpStun=Math.max(0,(p.stunTime||0)-dt);p.stunTime=p.pvpStun;for(const k of ['slow','corruptTime','burnTime'])p[k]=Math.max(0,(p[k]||0)-dt);p.pvpWeakness=teams[1-u.team].runtime.weaknessAt(p);p.pvpSlowFactor=p.pvpStun>0?.01:p.timeSlow>0?.30:p.slow>0?.70:1;}
 // Alternate team order to avoid always giving the first team the initiative.
 const order=Math.floor(clock*60)%2?[1,0]:[0,1];for(const t of order)if(living(t).length)teams[t].runtime.tick(dt,targets(t));
 for(const u of units){if(!Number.isFinite(u.actor.hp)||!Number.isFinite(u.actor.x)||!Number.isFinite(u.actor.y))throw Error('Invalid Journey actor '+u.id);}
 const alive=[living(0).length,living(1).length];if(!alive[0]||!alive[1]||remaining<=0){const score=t=>teams[t].units.reduce((n,u)=>n+Math.max(0,u.actor.hp)/u.actor.maxHp,0);winnerTeam=alive[0]&&!alive[1]?0:alive[1]&&!alive[0]?1:Math.abs(score(0)-score(1))<1e-7?null:score(0)>score(1)?0:1;winner=winnerTeam===null?null:teams[winnerTeam].units[0].id;finished=true;}
 }
 function actorWire(u){const p=u.actor;const visual={};for(const k of ['moving','mimicOrigin','mimicBoss','mimicNext','abCosmicUntil','abBeam','abActiveSpirits','newPose','mollitiamPose','mollitiamHeartTime','frogTime','ultimateBuff','ultimateBuffTime','ultimateTime','transformTime','atkTime','attackDelay','reach','skin62','secondaryCharging','secondaryCharge','realityRoll','godShadowUntil','dashTime','blinkSeq','darkAuraTime','crossTp','rewriteUntil','mimicMarks','mimicWardUntil','mimicGuardUntil','mimicVeilUntil','orbiters','pvpSlowFactor'])if(p[k]!==undefined)visual[k]=p[k];return {...visual,id:u.id,hero:p.type,originHero:u.hero,type:p.type,bot:u.bot===true,team:u.team,x:round(p.x),y:round(p.y),face:p.face,step:round(p.step),aim:round(p.aim,3),speed:round(p.speed),hp:Math.ceil(Math.max(0,p.hp)),maxHp:Math.ceil(p.maxHp),ult:Math.round(p.ultimateCharge),qCd:round(p.skillCd,1),eCd:round(p.secondaryCd,1),dashCd:round(p.dashCd,1),aura:round(p.darkAuraTime),shadows:0,transform:round(p.transformTime),defend:p.ultimateBuff==='defesa'?p.ultimateBuffTime:0,ultTimer:round(p.ultimateTime||p.ultimateBuffTime),ultMode:p.ultimateBuff||p.type,mirrorGuard:round(p.mirrorGuard),temporalField:0,voidUlt:round(p.voidUltimate),fieldX:0,fieldY:0,fieldRadius:0,stun:round(p.pvpStun),mirrorImages:0,atkFx:round(p.atkTime),atkAngle:p.aim,hitFx:0,blink:0,corruption:round(p.corruptTime)};}
 return {get finished(){return finished},get winner(){return winner},get winnerTeam(){return winnerTeam},tick(){const now=performance.now();let dt=Math.min(.09,Math.max(0,(now-lastAt)/1000));lastAt=now;while(dt>1e-5&&!finished){const s=Math.min(dt,1/60);step(s);dt-=s;}},input(id,input,s=0){const u=units.find(v=>v.id===id);if(!u||u.bot||finished||s&&s<=u.inputSeq)return false;if(s)u.inputSeq=s;u.actor.input={x:clamp(Number(input.x)||0,-1,1),y:clamp(Number(input.y)||0,-1,1),aim:Number.isFinite(input.aim)?input.aim:0,attack:!!input.attack};u.actor.inputAt=performance.now();return true;},action(id,n,v,a){const u=units.find(x=>x.id===id);return !!u&&!u.bot&&act(u,n,v,a);},snapshot(){const effects=teams.map(t=>t.runtime.effects());return {seq:++seq,stamp:round(clock,3),sim:round(teams[0].runtime.time,3),time:remaining,starting,players:units.map(actorWire),clones:effects.flatMap(e=>e.clones),projectiles:effects.flatMap(e=>e.projectiles),fx:[],visual:Object.fromEntries(['rings','slashes','timeFields','realityFields','mirrorIllusions','evePortals','xansBlasters','damageFloats'].map(k=>[k,effects.flatMap(e=>e[k]||[]).slice(-32)]))}},getClock:()=>round(clock,3),getTime:()=>round(remaining),getStarting:()=>round(starting),getActors:()=>units.map(u=>{const p=u.actor;return {id:u.id,x:p.x,y:p.y,face:p.face,step:round(p.step),aim:p.aim,hp:p.hp,blinkSeq:p.blinkSeq||0,moving:!!p.moving};})};
}
