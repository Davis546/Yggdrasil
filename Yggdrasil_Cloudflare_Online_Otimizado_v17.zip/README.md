# Yggdrasil v1.7 — Estabilidade de rede (Cloudflare)

Base **v1.5** (sem as novas animações do Cross da v1.6). Inclui a v1.5: cartas nerfadas, Sapo de uso único, modo cooperativo, sprites e música preservados.

## Correções

- Sala persistente após a partida: o anfitrião usa **TENTAR NOVAMENTE / MESMA SALA**; todos retornam à seleção dentro da mesma sala e não digitam o código novamente. Convidados podem solicitar revanche ao anfitrião.
- Seleção única: Loid, Kris ou Cross não podem ser duplicados na mesma sala.
- Convidados: predição local de movimento e reconciliação suave, snapshots adaptativos (90–250 ms conforme fila), entradas a 33 ms, menos efeitos temporários na rede e limite de carga do canal. O host segue autoritativo.
- FPS/rede/jitter e modo gráfico automático para diminuir a resolução interna **somente** caso o FPS esteja baixo, sem substituir sprites ou texturas.
- Configurações dos controles: tamanho 75–145%, joystick de ataque (arraste para mirar) e modo de renderização Auto/Leve/Alta.
- No celular em pé, os botões de poderes ficam acima dos botões de ataque e esquiva.

## Executar

`npm install` e `npx wrangler dev` para teste local. `npx wrangler deploy` para publicar após conferir a conta Cloudflare. Servidor exige Workers + Durable Objects.

## Limites

O desempenho final depende do navegador, distância da região Cloudflare e internet de cada jogador. Esta versão foi validada por análise estática/sintaxe; teste com três celulares reais ainda é necessário. O convidado usa predição de movimento, porém golpes e inimigos continuam controlados pelo anfitrião para evitar divergência.
