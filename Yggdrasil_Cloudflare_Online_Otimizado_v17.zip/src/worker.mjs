// Yggdrasil Online — Cloudflare Workers + Durable Objects (prototype)
// Host-authoritative: the host simulates combat; this Durable Object relays inputs/states.
import { DurableObject } from 'cloudflare:workers';

const HEROES = new Set(['loid', 'kris', 'cross']);
const BOSSES = new Set(['samurai', 'reuni', 'tsukuomi', 'pecado']);
const ACTIONS = new Set(['attack', 'q', 'eDown', 'eUp', 'dash', 'ultimate', 'card', 'ultimateChoice', 'f']);
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export class Lobby extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.rooms = new Map();
    this.players = new Map();
    this.nextId = 1;

    // Rebuild in-memory lobby from WebSocket attachments after DO hibernation.
    for (const socket of ctx.getWebSockets()) {
      const a = socket.deserializeAttachment() || {};
      const id = typeof a.id === 'string' ? a.id : String(this.nextId++);
      this.nextId = Math.max(this.nextId, (Number(id) || 0) + 1);
      const c = { id, socket, hero: a.hero || null, room: null };
      this.players.set(id, c);
    }
    for (const c of this.players.values()) {
      const a = c.socket.deserializeAttachment() || {};
      if (!a.code) continue;
      let room = this.rooms.get(a.code);
      if (!room) {
        room = { code: a.code, members: new Set(), host: null, started: !!a.started };
        this.rooms.set(a.code, room);
      }
      room.members.add(c);
      c.room = room;
      if (a.isHost) room.host = c;
    }
    for (const [code, room] of this.rooms) {
      if (!room.host) {
        for (const c of room.members) this.safeSend(c, { t: 'closed', message: 'Anfitrião desconectado.' });
        for (const c of room.members) { c.room = null; this.persist(c); }
        this.rooms.delete(code);
      }
    }
  }

  persist(c) {
    c.socket.serializeAttachment({
      id: c.id,
      code: c.room?.code || null,
      hero: c.hero || null,
      isHost: !!c.room && c.room.host === c,
      started: !!c.room?.started
    });
  }

  safeSend(c, value) {
    if (!c) return;
    try { c.socket.send(JSON.stringify(value)); } catch { /* disconnected */ }
  }

  members(room) {
    return [...room.members].map(c => ({ id: c.id, hero: c.hero || null }));
  }

  notify(room) {
    if (!room?.host) return;
    const state = { t: 'lobby', members: this.members(room), host: room.host.id, code: room.code, started: room.started };
    for (const c of room.members) this.safeSend(c, state);
  }

  makeCode() {
    let code;
    do {
      const b = crypto.getRandomValues(new Uint8Array(6));
      code = [...b].map(n => ALPHABET[n % ALPHABET.length]).join('');
    } while (this.rooms.has(code));
    return code;
  }

  joinRoom(c, room) {
    if (room.members.size >= 3) {
      this.safeSend(c, { t: 'error', message: 'Sala cheia (máximo 3 jogadores).' });
      return;
    }
    if (room.started) {
      this.safeSend(c, { t: 'error', message: 'Partida em andamento. Crie outra sala.' });
      return;
    }
    if (c.room) this.leaveRoom(c);
    room.members.add(c);
    c.room = room;
    c.hero = null;
    this.persist(c);
    this.safeSend(c, { t: 'welcome', id: c.id, code: room.code, host: room.host.id, members: this.members(room) });
    this.notify(room);
  }

  leaveRoom(c) {
    const room = c.room;
    if (!room) return;
    c.room = null;
    c.hero = null;
    room.members.delete(c);
    this.persist(c);
    if (room.host === c) {
      for (const member of room.members) {
        member.room = null;
        member.hero = null;
        this.persist(member);
        this.safeSend(member, { t: 'closed', message: 'O anfitrião saiu da sala.' });
      }
      this.rooms.delete(room.code);
      return;
    }
    if (room.members.size === 0) {
      this.rooms.delete(room.code);
      return;
    }
    this.notify(room);
    this.safeSend(room.host, { t: 'left', id: c.id });
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({ ok: true, rooms: this.rooms.size }), {
        headers: { 'content-type': 'application/json; charset=utf-8' }
      });
    }
    if (url.pathname !== '/ws' || request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') {
      return new Response('WebSocket required', { status: 426 });
    }
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    const c = { id: String(this.nextId++), socket: server, room: null, hero: null };
    this.players.set(c.id, c);
    this.persist(c);
    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(ws, raw) {
    const a = ws.deserializeAttachment() || {};
    const c = this.players.get(a.id);
    if (!c || typeof raw !== 'string' || raw.length > 180000) return;
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object' || typeof m.t !== 'string') return;
    if (m.t === 'ping') { this.safeSend(c,{t:'pong',ts:Number(m.ts)||Date.now()}); return; }

    if (m.t === 'create') {
      // New host room. If already in one, leave it before creating another.
      if (c.room) this.leaveRoom(c);
      const code = this.makeCode();
      const room = { code, host: c, members: new Set(), started: false };
      this.rooms.set(code, room);
      this.joinRoom(c, room);
      return;
    }
    if (m.t === 'join') {
      const code = String(m.code || '').trim().toUpperCase();
      const room = this.rooms.get(code);
      if (!room) { this.safeSend(c, { t: 'error', message: 'Sala não encontrada. Confira o código.' }); return; }
      this.joinRoom(c, room);
      return;
    }
    if (m.t === 'leave') { this.leaveRoom(c); return; }
    const r = c.room;
    if (!r) return;
    if (m.t === 'choose' && !r.started) {
      if (!HEROES.has(m.hero)) return;
      if ([...r.members].some(p => p !== c && p.hero === m.hero)) { this.safeSend(c, {t:'error',message:'Esse personagem já foi escolhido. Escolha outro!'}); return; }
      c.hero = m.hero;
      this.persist(c);
      this.notify(r);
      return;
    }
    if (m.t === 'begin' && r.host === c && !r.started) {
      if (r.members.size < 2 || [...r.members].some(p => !p.hero) || new Set([...r.members].map(p=>p.hero)).size !== r.members.size) {
        this.safeSend(c, { t: 'error', message: 'São necessários 2 ou 3 jogadores com personagem selecionado.' });
        return;
      }
      r.started = true;
      const boss = BOSSES.has(m.boss) ? m.boss : null;
      const difficulty = m.difficulty === 'pecador' ? 'pecador' : 'normal';
      const members = this.members(r);
      for (const p of r.members) {
        this.persist(p);
        this.safeSend(p, { t: 'begun', id: p.id, host: c.id, members, boss, difficulty });
      }
      return;
    }
    if (m.t === 'rematchRequest' && r.started && r.host !== c) { this.safeSend(r.host,{t:'rematchRequest',id:c.id});return; }
    if (m.t === 'rematch' && r.started && r.host === c) {
      r.started=false;
      for (const p of r.members) {p.hero=null;this.persist(p);this.safeSend(p,{t:'lobbyReset'});}
      this.notify(r);return;
    }
    if (!r.started) return;
    if (m.t === 'input' && r.host !== c) {
      const x = Number(m.x) || 0, y = Number(m.y) || 0, aim = Number(m.aim) || 0;
      this.safeSend(r.host, {
        t: 'remoteInput', id: c.id,
        x: Math.max(-1, Math.min(1, x)),
        y: Math.max(-1, Math.min(1, y)),
        aim: Number.isFinite(aim) ? aim : 0,
        attack: !!m.attack
      });
      return;
    }
    if (m.t === 'press' && r.host !== c && ACTIONS.has(m.action)) {
      this.safeSend(r.host, { t: 'remotePress', id: c.id, action: m.action, value: String(m.value || '').slice(0, 35) });
      return;
    }
    if (m.t === 'state' && r.host === c) {
      if (!m.data || typeof m.data !== 'object') return;
      const payload = JSON.stringify(m.data);
      if (payload.length > 96000) return;
      for (const p of r.members) if (p !== c) this.safeSend(p, { t: 'state', data: m.data });
      return;
    }
    if (m.t === 'signal' && r.host === c) {
      for (const p of r.members) {
        if (p.id === m.to) { this.safeSend(p, { t: 'signal', value: m.value }); break; }
      }
    }
  }

  webSocketClose(ws) {
    const a = ws.deserializeAttachment() || {};
    const c = this.players.get(a.id);
    if (!c) return;
    this.leaveRoom(c);
    this.players.delete(c.id);
  }

  webSocketError(ws) {
    this.webSocketClose(ws);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/ws' || url.pathname === '/health') {
      const id = env.LOBBY.idFromName('yggdrasil-global-lobby-v1');
      const stub = env.LOBBY.get(id);
      return stub.fetch(request);
    }
    return env.ASSETS.fetch(request);
  }
};
