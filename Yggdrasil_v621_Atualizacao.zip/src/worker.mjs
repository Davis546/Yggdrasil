import { unpackWorld616 } from './wire616.mjs';
import { createDuel } from './duel-engine.mjs';
// Yggdrasil Online v3.4 — Cloudflare Workers + Durable Objects (prototype)
// Host-authoritative: the host simulates combat; this Durable Object relays inputs/states.
import { DurableObject } from 'cloudflare:workers';

const HEROES = new Set(['loid', 'kris', 'cross', 'eve', 'kali', 'mollitiam', 'moretti', 'l0id', 'josue', 'mimic', 'abloy']);
const RESUME_MS = 120000;
const makeResumeToken=()=>Array.from(crypto.getRandomValues(new Uint8Array(24)),b=>b.toString(16).padStart(2,'0')).join('');
const MAX_COOP_PLAYERS = 5; // five players per room; six selectable heroes
const BOSSES = new Set(['japan', 'rush', 'defense', 'samurai', 'reuni', 'tsukuomi', 'pecado', 'nordic', 'frostjarl', 'odin', 'nameless', 'pecadoNordic']);
const NORSE_BOSSES=new Set(['nordic','frostjarl','odin','nameless','pecadoNordic']);
const WAIT_JP_POLYS=[[[650,345],[1184,345],[1200,570],[1150,620],[1100,675],[925,675],[870,620],[780,620],[710,670],[650,595],[620,535],[620,460]],[[330,505],[650,490],[665,565],[330,575]],[[205,575],[335,505],[350,575],[265,680],[255,750],[295,825],[330,900],[302,946],[217,850],[185,735],[180,650]]];
const WAIT_NPCS=[{id:'amaterasu',x:914,y:391},{id:'caine',x:1015,y:463}];
function waitingJapanWalk(x,y){const px=(x-244)*1448/960,py=(y-180)*1086/600;return WAIT_JP_POLYS.some(poly=>{let inside=false;for(let i=0,j=poly.length-1;i<poly.length;j=i++){const [xi,yi]=poly[i],[xj,yj]=poly[j];if((yi>py)!==(yj>py)&&px<(xj-xi)*(py-yi)/(yj-yi)+xi)inside=!inside;}return inside;})&&!WAIT_NPCS.some(n=>Math.hypot(x-n.x,y-n.y)<18);}
function waitingSpawn(i,nordic){return {x:nordic?584+(i%5)*70:780+(i%5)*58,y:nordic?600:490,face:'down',moving:false};}
const PASSIVE_IDS=new Set(['odin','tyr','ymir','sleipnir','eir','huginn']);
const validPassives=p=>Array.isArray(p)&&p.length===3&&new Set(p).size===3&&p.every(id=>PASSIVE_IDS.has(id));
const ACTIONS = new Set(['attack', 'q', 'eDown', 'eUp', 'dash', 'ultimate', 'card', 'ultimateChoice', 'f', 'mimic', 'shop', 'relic', 'shopTalk', 'shopExit']);
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
// The PvP draft is server-generated and server-validated. No instant-kill cards in PvP.
const PVP_CARDS = ['heart','blade','fast','speed','armor','reach','dodge','critical','arc','echo','ancient','shadowblade','shadowdash','darkburst','black','form','awakening','bloodmoon','mirror','mirrorguard','voidblade','timeward'];
function pvpOffer(hero){
  const pool = PVP_CARDS.filter(id=>!['shadowblade','shadowdash','darkburst'].includes(id)||hero==='loid').filter(id=>!['black','form','awakening','bloodmoon'].includes(id)||hero==='kris').filter(id=>!['mirror','mirrorguard'].includes(id)||hero==='kali').filter(id=>!['voidblade','timeward'].includes(id)||hero==='eve');
  for(let i=pool.length-1;i>0;i--){ const j=crypto.getRandomValues(new Uint32Array(1))[0]%(i+1); [pool[i],pool[j]]=[pool[j],pool[i]]; }
  return pool.slice(0,6);
}


const rankModes60=new Set(['rush','japan','nordic','defense']),rankKinds60=new Set(['solo','coop']),rankDiffs60=new Set(['normal','pecador']);
const rankJson60=(body,status=200)=>new Response(JSON.stringify(body),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
function rankCategory60(v){return rankModes60.has(v.mode)&&rankKinds60.has(v.kind)&&rankDiffs60.has(v.difficulty)?`rank60:${v.mode}:${v.kind}:${v.difficulty}`:null;}
async function ranking60(request,storage){const url=new URL(request.url);if(request.method==='GET'){const key=rankCategory60(Object.fromEntries(url.searchParams));if(!key)return rankJson60({error:'Categoria inválida'},400);return rankJson60({entries:await storage.get(key)||[],verified:false});}if(request.method!=='POST')return rankJson60({error:'Método inválido'},405);let v;try{const body=await request.text();if(body.length>2048)return rankJson60({error:'Pedido muito grande'},413);v=JSON.parse(body);}catch{return rankJson60({error:'JSON inválido'},400);}if(!v||typeof v!=='object')return rankJson60({error:'Dados inválidos'},400);const key=rankCategory60(v);const name=typeof v.name==='string'?v.name.trim().normalize('NFC'):'';const wave=v.wave;if(!key||!HEROES.has(v.hero)||!name||name.length>24||!/^[\p{L}\p{N} _.-]+$/u.test(name)||!Number.isInteger(wave)||wave<1||wave>(['rush','defense'].includes(v.mode)?10000:20))return rankJson60({error:'Dados inválidos'},400);const row={name,hero:v.hero,wave};await storage.transaction(async tx=>{const entries=await tx.get(key)||[];const i=entries.findIndex(x=>x.name.toLocaleLowerCase('pt-BR')===name.toLocaleLowerCase('pt-BR')&&x.hero===v.hero);if(i>=0&&entries[i].wave>=wave)return;if(i>=0)entries.splice(i,1);entries.push(row);entries.sort((a,b)=>b.wave-a.wave||a.name.localeCompare(b.name,'pt-BR')||a.hero.localeCompare(b.hero));await tx.put(key,entries.slice(0,100));});return rankJson60({ok:true,verified:false});}

const rankName62=p=>p>=1500?'Yggdrasil':p>=1000?'Divindade':p>=700?'Diamante':p>=450?'Platina':p>=250?'Ouro':p>=100?'Prata':'Bronze';
function identity62(m){const name=typeof m.name==='string'?m.name.trim().normalize('NFC'):'';return /^[a-f0-9]{48}$/.test(m.key||'')&&name.length>=1&&name.length<=24&&/^[\p{L}\p{N} _.-]+$/u.test(name)?{key:m.key,name}:null;}
const duelRankKey62=size=>'duelrank62:'+(size===4?4:2);
async function saveDuelRank62(storage,room){if(!room.ranked||room.roster?.some(p=>p.bot)||room.match.winnerTeam==null)return false;const fighters=[...room.members].filter(x=>x.role==='fighter');if(fighters.length!==room.size||fighters.some(x=>!x.duelIdentity))return false;const winner=room.match.winnerTeam;await storage.transaction(async tx=>{const key=duelRankKey62(room.size);const rows=await tx.get(key)||[];fighters.forEach((f,i)=>{let row=rows.find(x=>x.key===f.duelIdentity.key);if(!row){row={...f.duelIdentity,points:0,wins:0,losses:0};rows.push(row);}row.name=f.duelIdentity.name;const win=i%2===winner;row.points=Math.max(0,row.points+(win?25:-15));row.wins+=win?1:0;row.losses+=win?0:1;});rows.sort((a,b)=>b.points-a.points||b.wins-a.wins);await tx.put(key,rows.slice(0,1000));});return true;}
export class Lobby extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    this.rooms = new Map();
    this.players = new Map();
    this.nextId = 1;
    this.duelTicker = null;
    this.coopTicker = null;

    // Rebuild in-memory lobby from WebSocket attachments after DO hibernation.
    for (const socket of ctx.getWebSockets()) {
      const a = socket.deserializeAttachment() || {};
      const id = typeof a.id === 'string' ? a.id : String(this.nextId++);
      this.nextId = Math.max(this.nextId, (Number(id) || 0) + 1);
      const c = { id, socket, hero: a.hero || null, room: null, role:a.role||'fighter', offer:a.offer||[], picks:a.picks||[], passives:a.passives||[], token:a.token||null,wire616:a.wire616===true,duelIdentity:a.duelIdentity||null };
      this.players.set(id, c);
    }
    for (const c of this.players.values()) {
      const a = c.socket.deserializeAttachment() || {};
      if (!a.code) continue;
      let room = this.rooms.get(a.code);
      if (!room) {
        room = { code: a.code, members: new Set(), host: null, started: !!a.started, kind:a.kind||'coop', selectedBoss:a.boss||'japan', lastSnapshot:null, finished:false,size:a.duelSize===4?4:2,ranked:a.duelRanked===true,fillBots:a.duelRanked!==true&&a.duelFillBots===true,together:a.duelTogether===true };
        this.rooms.set(a.code, room);
      }
      room.members.add(c);
      c.room = room;
      if (a.isHost) room.host = c;
    }
    for (const [code, room] of this.rooms) {
      if(room.kind!=='pvp'){room.reserved=new Map();room.epoch=1;room.checkpoint=null;room.startInfo=null;}
      if (!room.host || room.started) {
        for (const c of room.members) this.safeSend(c, { t: 'closed', message: 'Anfitrião desconectado.' });
        for (const c of room.members) { c.room = null; this.persist(c); }
        this.rooms.delete(code);
      }
    }
  }

  persist(c) {
    if(!c.socket)return;
    c.socket.serializeAttachment({
      token:c.token||null,wire616:c.wire616===true,duelIdentity:c.duelIdentity||null,duelSize:c.room?.size||2,duelRanked:c.room?.ranked===true,duelFillBots:c.room?.fillBots===true,duelTogether:c.room?.together===true,
      id: c.id,
      code: c.room?.code || null,
      hero: c.hero || null,
      isHost: !!c.room && c.room.host === c,
      started: !!c.room?.started,
      boss:c.room?.selectedBoss||'japan',kind:c.room?.kind||'coop', role:c.role||'fighter', offer:c.offer||[], picks:c.picks||[],passives:c.passives||[]
    });
  }

  safeSend(c, value, encoded=null) {
    if (!c) return;
    try {
      // A slow guest must not accumulate an ever-growing queue of obsolete frames.
      // Critical events (cards, lobby, start, attack controls) are never dropped.
      if ((value.t === 'waitingMove' || value.t === 'motion' || value.t === 'state' || value.t === 'pvpSnapshot' || value.t === 'pvpMotion') &&
          typeof c.socket.bufferedAmount === 'number' && c.socket.bufferedAmount > (value.t==='motion'||value.t==='waitingMove'?24000:value.t==='state'&&!value.data?.mandatory?(c.wire616?16000:48000):131072)) return;
      c.socket.send(encoded??JSON.stringify(value));
    } catch { /* disconnected */ }
  }

  members(room) {
    return [...room.members].map(c => ({ id: c.id, hero: c.hero || null, passives:c.passives||[] }));
  }

  waitingPositions(room) {
    const positions={};let i=0;for(const c of room.members){if(!c.hero)continue;const spawn=waitingSpawn(i++,NORSE_BOSSES.has(room.selectedBoss));positions[c.id]=c.waitingPos||spawn;}return positions;
  }

  notify(room) {
    if (!room?.host) return;
    const state = { t: 'lobby', members: this.members(room), host: room.host.id, code: room.code, started: room.started, boss:room.selectedBoss||'japan', positions:room.started?undefined:this.waitingPositions(room) };
    for (const c of room.members) this.safeSend(c, state);
  }

  makeCode() {
    let code;
    do {
      const b = crypto.getRandomValues(new Uint8Array(6));
      code = [...b].map(n => ALPHABET[n % ALPHABET.length]).join('');
    } while (this.rooms.has(code));
    return code;
  }

  joinRoom(c, room) {
    if(room.kind === 'pvp') { this.safeSend(c,{t:'error',message:'Use o modo X1 para acessar essa sala.'}); return; }
    if(room.members.size||room.reserved?.size)this.sweepCoop(room);
    if (room.members.size+(room.reserved?.size||0) >= MAX_COOP_PLAYERS) {
      this.safeSend(c, { t: 'error', message: 'Sala cheia (máximo 5 jogadores).' });
      return;
    }
    if (room.started) {
      this.safeSend(c, { t: 'error', message: 'Partida em andamento. Crie outra sala.' });
      return;
    }
    if (c.room) this.leaveRoom(c);
    room.members.add(c);
    c.room = room;
    c.hero = null;c.passives=[];c.waitingPos=null;c.waitingAt=0;c.token=makeResumeToken();
    this.persist(c);
    this.safeSend(c, { t: 'welcome', wire616:1, id: c.id, code: room.code, host: room.host.id, members: this.members(room), token:c.token, epoch:room.epoch||1, boss:room.selectedBoss, positions:this.waitingPositions(room) });
    this.notify(room);
  }

  // Connected members and reserved slots are deliberately separate. The active
  // roster controls next-wave difficulty; reserved actors do not hold rewards open.
  ensureCoopTicker(){
    if(this.coopTicker)return;
    this.coopTicker=setInterval(()=>{
      for(const room of this.rooms.values())if(room.kind!=='pvp')this.sweepCoop(room);
      if(![...this.rooms.values()].some(r=>r.kind!=='pvp'&&(r.started||r.reserved?.size))){clearInterval(this.coopTicker);this.coopTicker=null;}
    },2000);this.coopTicker?.unref?.();
  }
  sweepCoop(room,now=Date.now()){
    if(!room.reserved)return;
    for(const [id,slot] of room.reserved)if(slot.until<=now)room.reserved.delete(id);
    if(!room.members.size&&!room.reserved.size)this.rooms.delete(room.code);
  }
  promoteCoop(room){
    const next=[...room.members][0];
    if(!next){room.host=null;return;}
    if(room.started&&!room.checkpoint){room.started=false;room.startInfo=null;for(const p of room.members)this.safeSend(p,{t:'lobbyReset'});}
    room.host=next;room.epoch=(room.epoch||1)+1;
    for(const p of room.members)this.persist(p);
    const base={t:'hostChanged',host:next.id,epoch:room.epoch,members:this.members(room),started:room.started};
    for(const p of room.members)this.safeSend(p,p===next?{...base,checkpoint:room.checkpoint}:base);
    this.notify(room);
  }
  leaveRoom(c, reserve=false) {
    const room=c.room;if(!room)return;
    if(room.kind==='pvp'){
      c.room=null;c.hero=null;c.passives=[];room.members.delete(c);this.persist(c);this.pvpLeave(c,room);return;
    }
    room.reserved??=new Map();
    if(reserve&&c.token){
      room.reserved.set(c.id,{id:c.id,token:c.token,hero:c.hero,passives:c.passives||[],until:Date.now()+RESUME_MS,
        waitingPos:c.waitingPos,actor:room.checkpoint?.actors?.[c.id]||null,chosenStage:room.checkpoint?.choices?.includes(c.id)?room.checkpoint.stage:null});
      this.ensureCoopTicker();
    }
    room.members.delete(c);c.room=null;c.hero=null;c.passives=[];this.persist(c);
    if(room.host===c){room.host=null;this.promoteCoop(room);}
    if(room.host){this.notify(room);this.safeSend(room.host,{t:'left',id:c.id,reserved:reserve});}
    this.sweepCoop(room);
  }
  resumeCoop(c,m){
    const room=this.rooms.get(String(m.code||'').toUpperCase());
    if(!room||room.kind==='pvp'||typeof m.token!=='string'||m.token.length!==48){this.safeSend(c,{t:'resumeDenied'});return;}
    this.sweepCoop(room);
    const entry=[...(room.reserved||new Map()).values()].find(p=>p.token===m.token);
    const live=[...room.members].find(p=>p.token===m.token);
    if(!entry&&!live){this.safeSend(c,{t:'resumeDenied'});return;}
    if(room.started&&!room.checkpoint){if(!room.host){room.started=false;room.startInfo=null;}else{this.safeSend(c,{t:'resumeWait'});return;}}
    if(c.room){this.safeSend(c,{t:'resumeDenied'});return;}
    const old=entry||live,oldId=old.id;const wasHost=room.host===live&&!!live;
    if(live){room.members.delete(live);this.players.delete(live.id);live.room=null;try{live.socket.close(4001,'Sessão substituída');}catch{}}
    room.reserved?.delete(oldId);this.players.delete(c.id);c.id=oldId;c.token=old.token;c.hero=old.hero;c.passives=old.passives||[];c.waitingPos=old.waitingPos||null;c.waitingAt=0;c.room=room;this.players.set(c.id,c);room.members.add(c);
    const takeover=wasHost||!room.host;
    if(takeover){room.host=c;room.epoch=(room.epoch||1)+1;}
    this.persist(c);
    const actor=entry?.actor||room.checkpoint?.actors?.[c.id]||null;
    this.safeSend(c,{t:'resumed',wire616:1,id:c.id,token:c.token,code:room.code,host:room.host.id,epoch:room.epoch||1,members:this.members(room),started:room.started,startInfo:room.startInfo,checkpoint:room.checkpoint,boss:room.selectedBoss,actor,positions:room.started?undefined:this.waitingPositions(room),returning:!!entry,chosenStage:entry?.chosenStage??null});
    if(takeover){for(const p of room.members)if(p!==c){this.persist(p);this.safeSend(p,{t:'hostChanged',host:c.id,epoch:room.epoch,members:this.members(room),started:room.started});}}
    else if(entry&&room.started)this.safeSend(room.host,{t:'rejoined',id:c.id,actor,chosenStage:entry.chosenStage});
    this.notify(room);
  }

  // Cloudflare Durable Object is the only authority for the duel. Neither browser runs combat.
  // One 20-Hz tick loop is shared across all active duels; stopped when no duels remain.
  ensureDuelTicker(){
    if(this.duelTicker)return;
    this.duelTicker=setInterval(()=>{
      let active=0;
      for(const room of this.rooms.values()){
        if(room.kind!=='pvp'||!room.started||room.finished||!room.match)continue;
        active++;
        try{
          room.match.tick();
          // 20Hz small motion updates, ~10Hz combat snapshots: fast movement without
          // resending spell FX, projectiles and all cooldowns on every frame.
          room.netTick=(room.netTick||0)+1;
          const actors=room.match.getActors();
          const motion={t:'pvpMotion',data:{seq:room.netTick,stamp:room.match.getClock(),time:room.match.getTime(),starting:room.match.getStarting(),players:actors.map((a,i)=>({id:a.id,x:Number(a.x.toFixed(2)),y:Number(a.y.toFixed(2)),face:a.face,step:a.step,aim:a.aim}))}};
          if(room.netTick%2===1 || !room.lastSnapshot){
            const packet={t:'pvpSnapshot',data:room.match.snapshot()};
            room.lastSnapshot=packet.data;
            for(const p of room.members)this.safeSend(p,packet);
          }else{
            for(const p of room.members)this.safeSend(p,motion);
          }
          if(room.match.finished){
            room.finished=true;
            const result={t:'pvpResult',winner:room.match.winner,winnerTeam:room.match.winnerTeam,reason:'DUELO ENCERRADO',ranked:false};
            const recipients=[...room.members];const done=ok=>{for(const p of recipients)if(p.room===room)this.safeSend(p,{...result,ranked:ok});this.pvpLobby(room);};
            if(room.ranked&&this.ctx?.storage){room.savingRank=true;const task=saveDuelRank62(this.ctx.storage,room).then(done,()=>done(false)).finally(()=>{room.savingRank=false;});this.ctx.waitUntil?.(task);}else done(false);
          }
        }catch(e){
          room.finished=true;
          for(const p of room.members)this.safeSend(p,{t:'error',message:'Erro na simulação do duelo. Volte à sala e tente novamente.'});
        }
      }
      if(!active){clearInterval(this.duelTicker);this.duelTicker=null;}
    },50);
  }
  pvpMembers(room){
    let i=0;const humans=[...room.members].filter(c=>c.role==='fighter');const together=room.fillBots&&room.together&&room.size===4&&humans.length===2;
    const members=[...room.members].map(c=>({id:c.id,role:c.role,team:c.role==='fighter'?(room.started&&room.roster?room.roster.find(p=>p.id===c.id)?.team:(together?0:i++%2)):null,hero:c.hero||null,chosen:(c.picks||[]).length,ready:(c.picks||[]).length===3&&!!c.hero}));
    if(room.started&&room.roster)members.push(...room.roster.filter(p=>p.bot).map(p=>({...p,role:'fighter',chosen:3,ready:true})));return members;
  }
  pvpLobby(room){
    const data={t:'pvpLobby',code:room.code,members:this.pvpMembers(room),host:room.host.id,started:room.started,finished:!!room.finished,size:room.size||2,ranked:!!room.ranked,fillBots:!!room.fillBots,together:!!room.together};
    for(const p of room.members)this.safeSend(p,data);
  }
  pvpLeave(c,room){
    if(room.host===c){
      for(const other of room.members){other.room=null;this.persist(other);this.safeSend(other,{t:'closed',message:'O anfitrião saiu da arena X1.'});}
      this.rooms.delete(room.code);return;
    }
    if(c.role==='fighter' && room.started && !room.finished){
      const survivor=[...room.members].find(x=>x.role==='fighter');
      room.finished=true;
      for(const other of room.members)this.safeSend(other,{t:'pvpResult',winner:room.size===4?null:survivor?.id||null,winnerTeam:null,ranked:false,reason:'Oponente desconectado'});
    }
    this.pvpLobby(room);
  }
  pvpJoin(c,room,role,identity=null){
    if(room.kind!=='pvp'){this.safeSend(c,{t:'error',message:'Esta não é uma sala X1.'});return;}
    if(room.members.size>=12){this.safeSend(c,{t:'error',message:'Arena cheia.'});return;}
    const fighters=[...room.members].filter(x=>x.role==='fighter');
    if(role==='fighter'&&(fighters.length>=(room.size||2)||room.started)){
      this.safeSend(c,{t:'error',message:'As vagas de lutador estão ocupadas. Entre como espectador.'});return;
    }
    if(role==='fighter'&&room.ranked&&(!identity||fighters.some(x=>x.duelIdentity?.key===identity.key))){this.safeSend(c,{t:'error',message:'Informe um apelido válido e use um perfil diferente por lutador.'});return;}
    if(c.room)this.leaveRoom(c);
    c.room=room;c.role=role;c.hero=null;c.picks=[];c.offer=[];c.duelIdentity=identity;
    room.members.add(c);this.persist(c);
    this.safeSend(c,{t:'pvpWelcome',id:c.id,code:room.code,role:c.role,host:room.host.id,offer:c.offer,
      members:this.pvpMembers(room),started:room.started,finished:!!room.finished,size:room.size||2,ranked:!!room.ranked,fillBots:!!room.fillBots,together:!!room.together});
    this.pvpLobby(room);
    if(room.started){
      this.safeSend(c,{t:'pvpBegin',size:room.size,fighters:room.roster||this.pvpMembers(room).filter(x=>x.role==='fighter').map(x=>({...x,cards:this.players.get(x.id)?.picks||[]})),
        hp:11200,host:room.host.id,spectator:true,authority:'server'});
      if(room.lastSnapshot)this.safeSend(c,{t:'pvpSnapshot',data:room.lastSnapshot});
    }
  }

  async fetch(request) {
    const url = new URL(request.url);
    if(url.pathname==='/duel-ranking'){if(request.method!=='GET')return rankJson60({error:'Método inválido'},405);const rows=await this.ctx.storage.get(duelRankKey62(Number(url.searchParams.get('size'))))||[];return rankJson60({entries:rows.slice(0,100).map(({name,points,wins,losses})=>({name,points,wins,losses,rank:rankName62(points)}))});}
    if (url.pathname === '/ranking') return ranking60(request,this.ctx.storage);
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({ ok: true, rooms: this.rooms.size }), {
        headers: { 'content-type': 'application/json; charset=utf-8' }
      });
    }
    if (url.pathname !== '/ws' || request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') {
      return new Response('WebSocket required', { status: 426 });
    }
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    const c = { id: String(this.nextId++), socket: server, room: null, hero: null };
    this.players.set(c.id, c);
    this.persist(c);
    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(ws, raw) {
    const a = ws.deserializeAttachment() || {};
    const c = this.players.get(a.id);
    if (!c || c.socket!==ws || typeof raw !== 'string' || raw.length > 750000) return;
    let m;
    try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m !== 'object' || typeof m.t !== 'string') return;
    if (m.t === 'ping') { this.safeSend(c,{t:'pong',ts:Number(m.ts)||Date.now(),mono:Number.isFinite(m.mono)?m.mono:undefined}); return; }

    if(m.t==='resume'){c.wire616=m.wire616===1;this.resumeCoop(c,m);return;}
    if(raw.length>180000&&!(m.t==='state'&&c.room?.host===c&&c.room.kind!=='pvp'))return;
    // PvP is isolated from the original cooperative protocol.
    if (m.t === 'pvpCreate') {
      const identity=identity62(m);if(m.ranked===true&&!identity){this.safeSend(c,{t:'error',message:'Digite um apelido válido para o competitivo.'});return;}
      if(c.room)this.leaveRoom(c);
      const code=this.makeCode();
      const room={code,host:c,members:new Set(),started:false,finished:false,kind:'pvp',lastSnapshot:null,size:m.size===4?4:2,ranked:m.ranked===true,fillBots:m.ranked!==true&&m.fillBots===true,together:m.ranked!==true&&m.together===true};
      this.rooms.set(code,room);
      this.pvpJoin(c,room,'fighter',identity);return;
    }
    if (m.t === 'pvpJoin') {
      const code=String(m.code||'').trim().toUpperCase();
      const room=this.rooms.get(code);
      if(!room){this.safeSend(c,{t:'error',message:'Sala X1 não encontrada.'});return;}
      this.pvpJoin(c,room,m.role==='spectator'?'spectator':'fighter',identity62(m));return;
    }
    if (m.t === 'pvpLeave'){this.leaveRoom(c);return;}
    if (c.room?.kind === 'pvp') {
      const r=c.room;
      if(m.t === 'pvpChoose'&&!r.started&&c.role==='fighter'){
        if(!HEROES.has(m.hero)||['moretti','l0id','josue','mimic','abloy'].includes(m.hero))return;
        if([...r.members].some(p=>p!==c&&p.role==='fighter'&&p.hero===m.hero)){
          this.safeSend(c,{t:'error',message:'Esse personagem já foi escolhido.'});return;
        }
        c.hero=m.hero;c.picks=[];c.offer=pvpOffer(c.hero);this.persist(c);this.safeSend(c,{t:'pvpDraft',offer:c.offer,picks:[]});this.pvpLobby(r);return;
      }
      if(m.t === 'pvpPick'&&!r.started&&c.role==='fighter'){
        const id=String(m.card||'');
        if(!c.hero || !c.offer.includes(id)||c.picks.includes(id)||c.picks.length>=3)return;
        c.picks.push(id);this.persist(c);
        this.safeSend(c,{t:'pvpDraft',offer:c.offer,picks:c.picks});this.pvpLobby(r);return;
      }
      if(m.t==='pvpBots'&&!r.started&&r.host===c&&!r.ranked){
        r.fillBots=m.fillBots===true;r.together=m.together===true;for(const p of r.members)this.persist(p);this.pvpLobby(r);return;
      }
      if(m.t==='pvpBegin'&&!r.started&&r.host===c){
        const fighters=[...r.members].filter(p=>p.role==='fighter');
        if((fighters.length!==(r.size||2)&&(!r.fillBots||r.ranked||!fighters.length))||fighters.some(p=>!p.hero||p.picks.length!==3)||new Set(fighters.map(p=>p.hero)).size!==fighters.length){
          this.safeSend(c,{t:'error',message:'Aguarde todos os lutadores com personagem e 3 cartas escolhidas.'});return;
        }
        r.started=true;r.finished=false;r.lastSnapshot=null;
        const roster=Array(r.size).fill(null);const together=r.fillBots&&!r.ranked&&r.together&&r.size===4&&fighters.length===2;
        fighters.forEach((p,i)=>{roster[together?i*2:i]={id:p.id,hero:p.hero,cards:p.picks,bot:false};});
        const used=new Set(fighters.map(p=>p.hero));const available=['loid','kris','cross','eve','kali','mollitiam'].filter(h=>!used.has(h));
        for(let i=0;i<roster.length;i++)if(!roster[i]){const j=crypto.getRandomValues(new Uint32Array(1))[0]%available.length;const hero=available.splice(j,1)[0];roster[i]={id:'bot:'+r.code+':'+i,hero,cards:pvpOffer(hero).slice(0,3),bot:true};}
        r.roster=roster.map((p,i)=>({...p,team:i%2}));r.match=createDuel(r.roster);
        this.ensureDuelTicker();
        const started={t:'pvpBegin',host:r.host.id,authority:'server',hp:11200,
          size:r.size||2,fighters:r.roster};
        for(const p of r.members){this.persist(p);this.safeSend(p,started);}this.pvpLobby(r);return;
      }
      // Server-authoritative movement and skills: applies equally to both fighters.
      if(m.t==='pvpInput'&&r.started&&!r.finished&&c.role==='fighter'&&r.match){
        const seq=Number.isSafeInteger(m.seq)&&m.seq>0?m.seq:0;
        r.match.input(c.id,{x:m.x,y:m.y,aim:m.aim,attack:m.attack},seq);
        return;
      }
      if(m.t==='pvpAction'&&r.started&&!r.finished&&c.role==='fighter'&&r.match){
        if(!['dash','q','e','eDown','eUp','r'].includes(m.action))return;
        // Rate limit actions even if a client attempts to spam websocket packets.
        const now=Date.now();if(!['eDown','eUp'].includes(m.action)&&c.lastSkillAt&&now-c.lastSkillAt<50)return;if(!['eDown','eUp'].includes(m.action))c.lastSkillAt=now;
        r.match.action(c.id,m.action,typeof m.variant==='string'?m.variant.slice(0,12):'',Number.isFinite(m.aim)?m.aim:0);
        const packet={t:'pvpSnapshot',data:r.match.snapshot()};r.lastSnapshot=packet.data;
        for(const p of r.members)this.safeSend(p,packet);
        return;
      }
      if(m.t==='pvpRematch'&&r.host===c&&r.started&&r.finished&&!r.savingRank){
        r.started=false;r.finished=false;r.lastSnapshot=null;r.match=null;r.roster=null;r.netTick=0;
        for(const p of r.members){p.picks=[];p.offer=p.role==='fighter'&&p.hero?pvpOffer(p.hero):[];this.persist(p);
          this.safeSend(p,{t:'pvpReset',offer:p.offer});}
        this.pvpLobby(r);return;
      }
      if(r.match)return; // Legacy host/P2P transport is intentionally disabled for this duel.
      // Secure WebRTC signaling within an active X1 room. Only the two verified
      // fighters may exchange offer/answer/ICE; spectators cannot inject signals.
      if(m.t==='pvpSignal'&&r.started&&!r.finished&&c.role==='fighter'){
        const other=[...r.members].find(p=>p.id===m.to&&p.role==='fighter'&&p!==c);
        if(!other || !m.data || !['offer','answer','candidate'].includes(m.data.type))return;
        const payload=JSON.stringify(m.data);
        if(payload.length>16000)return;
        this.safeSend(other,{t:'pvpSignal',from:c.id,data:m.data});return;
      }
      if(m.t==='pvpInput'&&r.started&&!r.finished&&c.role==='fighter'&&c!==r.host){
        const safe = v=>Number.isFinite(v)?Math.max(-1,Math.min(1,v)):0;
        this.safeSend(r.host,{t:'pvpInput',id:c.id,seq:Number.isSafeInteger(m.seq)&&m.seq>0?m.seq:0,data:{
          x:safe(m.x),y:safe(m.y),aim:Number.isFinite(m.aim)?m.aim:0,
          attack:!!m.attack,dash:!!m.dash,q:!!m.q,e:!!m.e,r:!!m.r,
          ult:typeof m.ult==='string'?m.ult.slice(0,10):''}});return;
      }
      if(m.t==='pvpAction'&&r.started&&!r.finished&&c.role==='fighter'&&c!==r.host){
        if(!['dash','q','e','eDown','eUp','r'].includes(m.action))return;
        this.safeSend(r.host,{t:'pvpAction',id:c.id,action:m.action,variant:String(m.variant||'').slice(0,10),aim:Number.isFinite(m.aim)?m.aim:0,x:Number.isFinite(m.x)?Math.max(-1,Math.min(1,m.x)):0,y:Number.isFinite(m.y)?Math.max(-1,Math.min(1,m.y)):0});return;
      }
      if(m.t==='pvpMotion'&&r.started&&!r.finished&&r.host===c){
        const d=m.data;
        if(!d||!Number.isSafeInteger(d.seq)||!Array.isArray(d.players)||d.players.length!==2)return;
        const valid=d.players.every(p=>typeof p.id==='string'&&Number.isFinite(p.x)&&Number.isFinite(p.y));
        if(!valid||JSON.stringify(d).length>2200)return;
        for(const other of r.members)if(other!==c)this.safeSend(other,{t:'pvpMotion',data:d});return;
      }
      if(m.t==='pvpSnapshot'&&r.started&&!r.finished&&r.host===c){
        if(!m.data||!Array.isArray(m.data.players)||m.data.players.length!==2)return;
        const payload=JSON.stringify(m.data);if(payload.length>17000)return;
        r.lastSnapshot=m.data;
        for(const other of r.members)if(other!==c)this.safeSend(other,{t:'pvpSnapshot',data:m.data});return;
      }
      if(m.t==='pvpResult'&&r.started&&!r.finished&&r.host===c){
        const fighters=[...r.members].filter(p=>p.role==='fighter');
        if(m.winner!==null&&!fighters.some(p=>p.id===m.winner))return;
        r.finished=true;
        for(const other of r.members)this.safeSend(other,{t:'pvpResult',winner:m.winner,reason:'DUELO ENCERRADO'});
        this.pvpLobby(r);return;
      }
      return;
    }
    if (m.t === 'create') {
      c.wire616=m.wire616===1;
      // New host room. If already in one, leave it before creating another.
      if (c.room) this.leaveRoom(c);
      const code = this.makeCode();
      const room = { code, host: c, members: new Set(), reserved:new Map(), epoch:1, checkpoint:null, startInfo:null, started: false, selectedBoss:['japan','nordic','rush','defense'].includes(m.boss)?m.boss:'japan' };
      this.rooms.set(code, room);
      this.joinRoom(c, room);
      return;
    }
    if (m.t === 'join') {
      c.wire616=m.wire616===1;
      const code = String(m.code || '').trim().toUpperCase();
      const room = this.rooms.get(code);
      if (!room) { this.safeSend(c, { t: 'error', message: 'Sala não encontrada. Confira o código.' }); return; }
      this.joinRoom(c, room);
      return;
    }
    if (m.t === 'leave') { this.leaveRoom(c); return; }
    const r = c.room;
    if (!r) return;
    if(m.t==='waitingMove'&&!r.started&&c.hero){
      const now=Date.now();if(c.waitingAt&&now-c.waitingAt<55)return;
      if(!Number.isFinite(m.x)||!Number.isFinite(m.y))return;
      c.waitingAt=now;
      const pos={x:Math.round(Math.max(360,Math.min(1088,m.x))),y:Math.round(Math.max(365,Math.min(760,m.y))),face:['up','down','left','right'].includes(m.face)?m.face:'down',moving:m.moving===true};
      if(!NORSE_BOSSES.has(r.selectedBoss)&&!waitingJapanWalk(pos.x,pos.y))return;
      c.waitingPos=pos;
      const packet={t:'waitingMove',id:c.id,...pos};const wire=JSON.stringify(packet);
      for(const peer of r.members)if(peer!==c)this.safeSend(peer,packet,wire);
      return;
    }
    if (m.t === 'choose' && !r.started) {
      if (!HEROES.has(m.hero)) return;
      if ([...r.members].some(p => p !== c && p.hero === m.hero)) { this.safeSend(c, {t:'error',message:'Esse personagem já foi escolhido. Escolha outro!'}); return; }
      c.hero = m.hero;
      c.waitingPos=this.waitingPositions(r)[c.id];
      this.persist(c);
      this.notify(r);
      return;
    }
    if(m.t==='mode' && !r.started && r.host===c){
      const wasNorse=NORSE_BOSSES.has(r.selectedBoss);r.selectedBoss=BOSSES.has(m.boss)?m.boss:'japan';
      for(const p of r.members){if(wasNorse!==NORSE_BOSSES.has(r.selectedBoss))p.waitingPos=null;this.persist(p);}
      this.notify(r);return;
    }
    if(m.t==='passives' && !r.started){
      const picked=m.passives;
      if(!Array.isArray(picked)||picked.length>3||new Set(picked).size!==picked.length||!picked.every(id=>PASSIVE_IDS.has(id)))return;
      c.passives=picked.slice();this.persist(c);this.notify(r);return;
    }
    if (m.t === 'begin' && r.host === c && !r.started) {
      this.sweepCoop(r);
      if(r.reserved?.size){this.safeSend(c,{t:'error',message:'Aguarde os aliados reconectarem ou a reserva expirar.'});return;}
      if (r.members.size < 2 || [...r.members].some(p => !p.hero) || new Set([...r.members].map(p=>p.hero)).size !== r.members.size) {
        this.safeSend(c, { t: 'error', message: 'São necessários de 2 a 5 jogadores com personagens diferentes selecionados.' });
        return;
      }
      const boss = BOSSES.has(m.boss) ? m.boss : null;
      if(NORSE_BOSSES.has(boss)&&[...r.members].some(p=>!validPassives(p.passives))){
        this.safeSend(c,{t:'error',message:'Todos precisam escolher 3 passivas nórdicas antes de começar.'});return;
      }
      r.started = true;
      const difficulty = m.difficulty === 'pecador' ? 'pecador' : 'normal';
      const members = this.members(r);
      r.startInfo={boss,difficulty};r.checkpoint=null;this.ensureCoopTicker();
      for (const p of r.members) {
        this.persist(p);
        this.safeSend(p, { t: 'begun', id: p.id, host: c.id, members, boss, difficulty, playerCount: members.length, epoch:r.epoch||1 });
      }
      return;
    }
    if (m.t === 'rematchRequest' && r.started && r.host !== c) { this.safeSend(r.host,{t:'rematchRequest',id:c.id});return; }
    if (m.t === 'rematch' && r.started && r.host === c) {
      r.started=false;r.selectedBoss='japan';r.checkpoint=null;r.startInfo=null;r.reserved?.clear();
      for (const p of r.members) {p.passives=[];p.hero=null;p.waitingPos=null;p.waitingAt=0;this.persist(p);this.safeSend(p,{t:'lobbyReset'});}
      this.notify(r);return;
    }
    if (!r.started) return;
    if(m.t==='detached'&&r.host===c){const slot=r.reserved?.get(String(m.id));if(slot&&m.actor&&typeof m.actor==='object'&&JSON.stringify(m.actor).length<30000){slot.actor=m.actor;slot.chosenStage=Number.isInteger(m.chosenStage)?m.chosenStage:null;}return;}
    if (m.t === 'input' && r.host !== c) {
      const x = Number(m.x) || 0, y = Number(m.y) || 0, aim = Number(m.aim) || 0;
      this.safeSend(r.host, {
        t: 'remoteInput', id: c.id,
        x: Math.max(-1, Math.min(1, x)),
        y: Math.max(-1, Math.min(1, y)),
        aim: Number.isFinite(aim) ? aim : 0,
        attack: !!m.attack
      });
      return;
    }
    if (m.t === 'press' && r.host !== c && ACTIONS.has(m.action)) {
      this.safeSend(r.host, { t: 'remotePress', id: c.id, action: m.action, value: String(m.value || '').slice(0, 35),
        aim:Number.isFinite(m.aim)?m.aim:0,
        dx:Number.isFinite(m.dx)?Math.max(-1,Math.min(1,m.dx)):0,
        dy:Number.isFinite(m.dy)?Math.max(-1,Math.min(1,m.dy)):0
      });
      return;
    }
    if (m.t === 'motion' && r.host === c) {
      if(m.epoch!==undefined&&m.epoch!==(r.epoch||1))return;
      // Verify compact movement-only packets; do not let large payloads congest the room.
      if (!m.actors || typeof m.actors !== 'object' || Object.keys(m.actors).length > MAX_COOP_PLAYERS || JSON.stringify(m).length > 2400) return;
      const positions = {};
      for (const p of r.members) {
        const a = m.actors[p.id];
        if(!a)continue;if(!Number.isFinite(a.x)||!Number.isFinite(a.y))return;
        positions[p.id] = { x:a.x, y:a.y, face:String(a.face||'down').slice(0,5), step:Number(a.step)||0, hp:Number(a.hp)||0, blinkSeq:Math.max(0,Math.floor(Number(a.blinkSeq)||0)), blinking:a.blinking===true, vx:Number.isFinite(a.vx)?Math.max(-650,Math.min(650,a.vx)):undefined, vy:Number.isFinite(a.vy)?Math.max(-650,Math.min(650,a.vy)):undefined };
      }
      const packet={t:'motion',epoch:r.epoch||1,seq:Number(m.seq)||0,stage:Number.isInteger(m.stage)?m.stage:undefined,sim:Number.isFinite(m.sim)?m.sim:undefined,hostRtt:Number.isFinite(m.hostRtt)?Math.max(0,Math.min(1000,m.hostRtt)):undefined,actors:positions};const encoded=JSON.stringify(packet);for (const p of r.members) if (p !== c) this.safeSend(p,packet,encoded);
      return;
    }
    if (m.t === 'state' && r.host === c) {
      if (!m.data || typeof m.data !== 'object') return;
      if(m.epoch!==undefined&&m.epoch!==(r.epoch||1))return;
      if(m.checkpoint&&typeof m.checkpoint==='object'&&m.checkpoint.actors?.[c.id]){
        const cp=unpackWorld616(m.checkpoint);if(cp&&JSON.stringify(cp).length<560000)r.checkpoint=cp;
      }
      const payload=JSON.stringify(m.data);if(payload.length>180000)return;
      const packet={t:'state',epoch:r.epoch||1,data:m.data};const encoded='{"t":"state","epoch":'+(r.epoch||1)+',"data":'+payload+'}';
      // Modern peers receive the compact wire directly; old browsers get the same decoded state.
      let legacy=null,legacyEncoded=null;
      for(const p of r.members)if(p!==c){
        if(m.data.wire616!==1||p.wire616)this.safeSend(p,packet,encoded);
        else {if(!legacy){const data=unpackWorld616(m.data);if(!data)return;legacy={...packet,data};legacyEncoded=JSON.stringify(legacy);}this.safeSend(p,legacy,legacyEncoded);}
      }
      return;
    }
    if (m.t === 'signal' && r.host === c) {
      for (const p of r.members) {
        if (p.id === m.to) { this.safeSend(p, { t: 'signal', value: m.value }); break; }
      }
    }
  }

  webSocketClose(ws) {
    const a = ws.deserializeAttachment() || {};
    const c = this.players.get(a.id);
    if (!c||c.socket!==ws) return;
    this.leaveRoom(c,true);
    this.players.delete(c.id);
  }

  webSocketError(ws) {
    this.webSocketClose(ws);
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if(url.pathname==='/net-edge')return new Response(JSON.stringify({ok:true,colo:request.cf?.colo||'unknown'}),{headers:{'content-type':'application/json','cache-control':'no-store'}});
    if(url.pathname==='/ranking'){const id=env.LOBBY.idFromName('yggdrasil-world-ranking-v60');return env.LOBBY.get(id).fetch(request);}
    if (url.pathname === '/ws' || url.pathname === '/health' || url.pathname === '/duel-ranking') {
      const id = env.LOBBY.idFromName('yggdrasil-sam-lobby-v493');
      const stub = env.LOBBY.get(id,{locationHint:'sam'});
      return stub.fetch(request);
    }
    return env.ASSETS.fetch(request);
  }
};
