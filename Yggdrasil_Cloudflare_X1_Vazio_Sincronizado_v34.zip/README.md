# YGGDRASIL v3.4 — Coop + X1 online sincronizados

Base: v3.3. Mantém sprites, cinco jogadores no cooperativo, dois lutadores + espectadores no X1, cartas e OSTs.

## Correções prioritárias
- **Expansão do Vazio do Eve Lorey (coop):** o servidor anfitrião agora processa o tempo e a desintegração do supremo mesmo quando **Eve é jogador convidado**. Inimigos comuns vivos são eliminados na fase de colapso; chefes sofrem 20% da vida máxima. A arena escurece para todos, e a mensagem indica o número de inimigos desintegrados.
- **Expansão do Vazio (X1):** tela de escuridão e runas para os dois lutadores e espectadores, colapso depois de uma preparação de ~1,4 s e 20% da vida máxima do rival (sem instant kill em PvP), efeitos visuais replicados via estado oficial.
- **X1 — movimento e rede:** predição local sem puxar o convidado para a posição antiga do anfitrião. Extrapolação visual curta dos outros personagens, snapshots com número de sequência e descartes de pacotes velhos, menos partículas enviadas e atualização imediata após ações importantes. Os acertos seguem autoritativos no anfitrião.
- **Paridade de habilidades:** área do Q do Eve de 45px com dano de chefe, campo do tempo E estacionário que afeta movimentação e tiros dentro do círculo, tempo da Defesa do Kris em 3 s, duração dos quatro buffs do Kris alinhada ao solo, Q do Xans com stun de 2 s no alvo, carga do R por golpes acertados (Eve Lorey carrega mais lentamente, como na campanha) e Corte Dimensional do Kris com 1,6 s de carga.
- Barra de conexão agora informa FPS, ping, jitter e total de snapshots recebidos.
- Número da versão **v3.4** nos menus e nos arquivos para evitar confusão de cache.

## Instalar e publicar
Envie ZIP para raiz do repositório Github e execute no Codespaces:

```sh
git pull && unzip -o Yggdrasil_Cloudflare_X1_Vazio_Sincronizado_v34.zip -d . && npm install && npx wrangler deploy
```

Para guardar alterações no Github: `git add public src package.json wrangler.jsonc README.md && git commit -m "Yggdrasil v3.4 - X1 online e vazio" && git push` (se houver mudanças).

## Testes ainda necessários
1. Dois navegadores reais no Cloudflare: convidado se move e ataca sem ser puxado para trás.
2. Um jogador convidado Eve Lorey no cooperativo: carregar R e observar todos os Onis desintegrarem.
3. Eve Lorey no X1: as duas telas escurecem, o inimigo sofre exatamente 20% da vida máxima após a animação e a vida sincroniza.
4. Confirmar que Kali/Loid/Kris/Xans continuam funcionando no cooperativo e X1.

O X1 ainda usa sua própria simulação autoritativa adaptada para PvP (para impedir eliminação instantânea), **não é literalmente o mesmo motor da campanha**. A paridade de habilidades foi melhorada, mas a unificação completa fica pendente de uma refatoração mais profunda. O teste local não garante a latência real de dois dispositivos pela rede.
