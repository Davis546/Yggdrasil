# Yggdrasil v2.4 — Mira mobile, coop e otimização do Supremo do Loid

Derivado da **v2.3**, que já inclui: dificuldade Normal/Pecador selecionável na sala online, mira assistida no ataque e poderes do celular, joystick corrigido e música inicial mais baixa. **Nenhuma habilidade foi nerfada por esta atualização.**

## Melhorias visuais e de performance
- O **Domínio de Escuridão (R)** e a aura (Q) de Loid agora usam gradientes **pré-renderizados uma única vez** em canvas auxiliar, evitando calcular efeitos grandes a cada quadro.
- Em aparelho fraco ou modo Desempenho, campo escuro e aura usam formas simplificadas sem blur; o raio de dano, duração, velocidade, esquiva e invulnerabilidade ficam **iguais**.
- Modo Auto: começa em nível leve se detectar hardware móvel restrito, mede a fluidez e ajusta resolução interna e quantidade de efeitos após queda de FPS; recupera detalhe somente após estabilidade prolongada.
- Modo Desempenho: reduz o custo dos efeitos e limita a apresentação visual a aproximadamente 30 FPS; física, comandos e sincronização de rede não são limitados junto com a renderização.
- Limites adaptativos para partículas e rastros de dash; efeitos de jogadores aliados são representados com formas mais econômicas em celulares fracos.
- HUD informa **FPS de desenho real**, modo auto e latência (quando disponíveis).
- Sprites e mapas originais continuam no pacote sem substituição.

## Publicar
1. Envie o ZIP **Yggdrasil_Cloudflare_Mobile_Desempenho_v24.zip** à raiz do repositório GitHub.
2. No GitHub Codespaces execute:

```sh
git pull && unzip -o Yggdrasil_Cloudflare_Mobile_Desempenho_v24.zip -d . && npm install && npx wrangler deploy
```

3. Reabra/atualize a página em todos os celulares e PCs.

> Validação local não substitui testes de FPS/latência em celulares reais.
