# YGGDRASIL v2.0 — Sincronização cooperativa corrigida

**Esta atualização preserva todo o conteúdo da v1.9:** Loid, Kris e Cross, cartas, sprites e OSTs, transformação do sapo, chefes e modo desempenho.

## Correção do multiplayer
- A partida é **uma simulação autoritativa no anfitrião**. Os convidados enviam direções/ataques/poderes e recebem de volta o mesmo estado de inimigos e chefes. O servidor Cloudflare Durable Objects é o relay das salas.
- Mensagens `press` agora carregam direção e mira do convidado (antes o anfitrião podia usar informações desatualizadas). **O mesmo ataque entra na simulação de dano do anfitrião.**
- Ao realizar um ataque, dash, Q, E, R ou F de convidado, o anfitrião transmite estado imediato. A ação aparece para todos mais depressa.
- Os clientes veem **todos os inimigos e projéteis**, não apenas os próximos da câmera do anfitrião. Animações de andar e variáveis de batalha são enviadas completas.
- **Posições do inimigo interpoladas** entre estados em 8Hz; renderização no ritmo do dispositivo. Dano e HP continuam do anfitrião, sem simulação paralela no convidado.
- Ataque e dash respondem visualmente de imediato no convidado; a confirmação de dano vem no estado autoritativo.
- Escolhas de cartas, teste direto dos chefes, modo desempenho e reinício na mesma sala são preservados.

## Deploy pelo GitHub Codespaces + Cloudflare
Extraia os arquivos do ZIP **na raiz do repositório** (arquivos `wrangler.jsonc`, `package.json`, pastas `src/`, `public/`).

```bash
npm install && npx wrangler deploy
```
Se você enviou o ZIP inteiro sem extrair, no Codespaces:

```bash
git pull && unzip -o Yggdrasil_Cloudflare_Coop_Sincronizado_v20.zip -d . && npm install && npx wrangler deploy
```

## Como testar
1. Abra o link do Cloudflare em duas janelas (ou celular + PC), crie sala e entre com código.
2. Selecione heróis diferentes e inicie. Cada pessoa deve ver o **mesmo HP de um Oni**, mover-se e usar J, Q, E, Espaço e R.
3. Confira se os ataques do convidado diminuem a vida do mesmo inimigo para os dois, se dash e poderes são visíveis e se um chefe tem a mesma vida para todos.
4. Uma atualização da hospedagem com abas antigas abertas pode misturar protocolos. Atualize todas as abas com recarga forte após publicar.

**Observação:** ainda é arquitetura host-autoritativa: se o anfitrião fechar o jogo, a partida para. Não é um servidor com IA completamente independente. A validação final exige testes na Cloudflare com dois ou três jogadores reais.
