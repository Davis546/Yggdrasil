# YGGDRASIL v3.1 — Combate original restaurado

Esta revisão preserva a base v3.0 e **não muda o kit nem o balanceamento dos cinco protagonistas** (com exceção de devolver ao Loid no X1 o alcance curto de adaga que seu kit sempre deveria ter).

## O que mudou

- **X1 — Loid, adaga corpo a corpo:** alcance padrão corrigido de 97 para **46 unidades**. O golpe e o arco visível são curtos. Cartas de alcance permanecem limitadas como anteriormente.
- **X1 — Quatro Sombras (E):** em vez de quatro formas geométricas paradas, são quatro sprites sombrios animados que seguem Loid, perseguem o oponente próximo e atacam corpo a corpo. Cálculo de dano e posições ocorrem somente no anfitrião; os convidados recebem os mesmos clones pelo snapshot. A duração e o cooldown da habilidade permanecem os anteriores.
- **X1 — Aura de Escuridão (Q) e domínio (R):** novamente desenhados como área escura pulsante sob os personagens, com anéis de magia, mantendo os efeitos, duração e dano preexistentes.
- **X1 — Kris (E):** o Corte Dimensional voltou a ter um rasgo visual violeta, branco, grosso, com faíscas, em vez de uma linha simples. Poder, recarga, alcance e dano inalterados.
- **X1 — Xans (R):** as caveiras e feixes usam sprite de caveira pixel art, não apenas um caractere de texto. Dano/buffs e demais habilidades inalterados.
- **X1 — Eve Lorey:** os portais preservam a animação em pixel art e agora têm efeito adicional de distorção na saída e chegada. Demais habilidades inalteradas.
- **X1 — Kali:** ilusões se movem visualmente ao redor dela. Espelho/projéteis e mecânicas de suporte preservados.
- **Celular e X1 — interface:** os botões Q/E/R voltaram a mostrar as **estrelas ✦ / ✧ / ✶** com pequena etiqueta da tecla, sem miniaturas de habilidades nem letras isoladas.
- **Performance:** o anfitrião continua desenhando os quadros localmente sem limitar o render à frequência dos pacotes de rede; as sombras usam sprites pré-coloridos, sem filtros caros por quadro.
- **Versão:** o menu principal e o X1 mostram **v3.1**.

## Publicar no Cloudflare com Codespaces

1. Envie o ZIP ao repositório GitHub (pasta raiz), abra o Codespaces.
2. Cole no terminal:

```bash
git pull && unzip -o Yggdrasil_Cloudflare_Combate_Classico_v31.zip -d . && npm install && npx wrangler deploy
```

Opcional, para registrar as alterações também no GitHub:

```bash
git add public src package.json wrangler.jsonc README.md && (git diff --cached --quiet || git commit -m "Yggdrasil v3.1 - combate clássico") && git push
```

3. Atualize a página do jogo no celular e no computador após o deploy. Não é necessário alterar seu endereço público `.workers.dev`.

## Testes e limites

- `node --check` para o JavaScript do jogo e do duelo.
- Testes isolados em Node confirmam alcance curto da adaga; quatro sombras com movimento independente, perseguição, retorno ao Loid e acerto; estado das sombras incluído no snapshot; e renderização do anfitrião desacoplada da transmissão.
- **Ainda não foi possível executar uma partida completa em navegador nesta sessão**, porque o Chromium do ambiente bloqueia a navegação mesmo para páginas locais. É necessário confirmar a aparência e a fluidez com dois aparelhos no Cloudflare.
